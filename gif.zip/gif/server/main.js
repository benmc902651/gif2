import { Meteor } from 'meteor/meteor';

//Session.set('gifshotReady', false);

Meteor.startup(() => {
  // code to run on server at startup
 
  UploadServer.init({
    tmpDir: process.env.PWD + '/public/uploads~',
    uploadDir: process.env.PWD + '/public/uploads~',
    checkCreateDirectories: true,
    overwrite: true,
    uploadUrl: '/upload~'
  });
});
