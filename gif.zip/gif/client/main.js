import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import { Session } from 'meteor/session';

import './main.html';

// Session.set('gifImage',null);

// Template.dragdrop.onRendered(function(){ 
//   var myDropzone = new Dropzone("div#dropZone", { url: "/uploads~", uploadMultiple:true,   addRemoveLinks:true, autoDiscovery:false, maxFiles:5});;

//   myDropzone.on("queuecomplete", function() {

//     var actions = myDropzone.files.map(fn);
//     var results = Promise.all(actions);
  
//     results.then(images => 
//         gifshot.createGIF({
//         images: images,
//         interval:.8
//       },function(obj) {
//             if(!obj.error) {
//               Session.set('gifImage',obj.image);
//             }
//           })
//       );
//   });
//  }) 

// Template.gif.helpers({
//   gifImage: function() {
//     return Session.get('gifImage');
//   }
// })

// var fn = function pFileReader(file){
//   return new Promise((resolve, reject) => {
//     var fr = new FileReader();  
//     fr.onload = function(){
//       resolve(this.result);
//     };
//     fr.readAsDataURL(file);
//   });
//}
