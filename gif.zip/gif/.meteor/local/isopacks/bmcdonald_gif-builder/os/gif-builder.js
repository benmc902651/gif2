// Write your package code here!

function fileReadTest(){
    
        var fr = new FileReader();  
        fr.onload = function(){
          resolve(this.result);
        };
        fr.readAsDataURL('http://localhost/uploads~/unit-test.jpg');
    
      }
    
function createGifTest(){
        
        gifshot.createGIF({
            images: ['http://localhost/uploads~/unit-test.jpg'],
            interval: .8
          },function(obj) {
                if(!obj.error) {
                    return obj.image;
                }
              })
}

// Variables exported by this module can be imported by other packages and
// applications. See gif-builder-tests.js for an example of importing.
export const name = 'gifbuilder';


