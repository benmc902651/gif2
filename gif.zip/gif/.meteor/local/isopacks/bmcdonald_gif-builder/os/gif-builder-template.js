
Session.set('gifImage',null);
Session.set('interval',".8");
Session.set('save',"");

Template.gifbuilder.onRendered(function(){ 
    var myDropzone = new Dropzone("div#dropZone", { url: "/uploads~", uploadMultiple:true,   addRemoveLinks:true, autoDiscovery:false, maxFiles:5});

    myDropzone.on("queuecomplete", function() {
            var actions = myDropzone.files.map(fn);
            var results = Promise.all(actions);
          
            results.then(images => 
                gifshot.createGIF({
                images: images,
                interval: Session.get('interval')
              },function(obj) {
                    if(!obj.error) {
                      Session.set('gifImage',obj.image);
                      Session.set('save',"Double Click or Right Click to Save As");
                    }
                  })
              );
          });
})

Template.gifbuilder.helpers({
    gifImage: function() {
      return Session.get('gifImage');
    },
    interval: function() {
        return Session.get('interval');
      },
    save: function() {
        return Session.get('save');
      },  
  })

  Template.gifbuilder.events({
    'input #interval': function(event) {
        Session.set('interval', event.currentTarget.value );
    }
  })

var fn = function pFileReader(file){
    return new Promise((resolve, reject) => {
      var fr = new FileReader();  
      fr.onload = function(){
        resolve(this.result);
      };
      fr.readAsDataURL(file);
    });
  }